<?php
/**
 * @package     HomePage
 * @subpackage  mod_homepage
 *
 * @copyright   Copyright (C) 2021 Adrien Beaugendre. All rights reserved.
 * @license     GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.ht
 */

defined('_JEXEC') or die;

?>
<h1> Bonjour !</h1>
